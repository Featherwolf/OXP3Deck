# Adapted from ClawDeck (MIT, Copyright (c) 2026 IHulkSmashI and ClawDeck contributors). See THIRD_PARTY_NOTICES.md.
"""OXP3Deck: the Decky Loader backend. Thin: each method is one call into py_modules/oxp3deck, run in an executor
thread, and answers {ok, error, ...} (DESIGN.md "Backend API"). Runs as root (plugin.json flag "root").

Decky starts _main as a task nobody awaits and serves calls at the same time, so everything a call needs is set up
in __init__; when that fails, every call answers {ok: false, error} instead of raising (Decky drops the message of
a Python exception on its way to the frontend).
"""
import asyncio
import functools
import importlib
import json
import logging
import os
import re
import sys
import traceback

PLUGIN_DIR = os.path.dirname(os.path.realpath(__file__))
_PY_MODULES = os.path.join(PLUGIN_DIR, "py_modules")
if sys.path[:1] != [_PY_MODULES]:
    sys.path.insert(0, _PY_MODULES)

from oxp3deck import env  # noqa: E402

# Decky is a PyInstaller bundle: its LD_LIBRARY_PATH (and friends) would reach every program the plugin starts.
env.scrub_process_env()

import decky  # noqa: E402

from oxp3deck import context, jobs, sysexec  # noqa: E402

log = logging.getLogger("oxp3deck")
_BROKEN: dict = {}     # module name -> why it did not import


def _load(name: str):
    """A feature module; one that fails to import turns only its own calls into errors."""
    try:
        return importlib.import_module("oxp3deck." + name)
    except Exception as e:
        _BROKEN[name] = f"{type(e).__name__}: {e}"
        log.error("cannot load oxp3deck.%s:\n%s", name, traceback.format_exc())
        return None


oxp3tool = _load("oxp3tool")
xess = _load("xess")
games = _load("games")
power = _load("power")              # (powerhw is imported by power)
readouts = _load("readouts")
extras = _load("extras")
optiscaler = _load("optiscaler")
autosetup = _load("autosetup")

OXP3_VENDOR = "ONE-NETBOOK"          # oxp3_tool/detect.py OXP3_SYS_VENDOR / OXP3_PRODUCT_NAME
OXP3_PRODUCT = "ONEXPLAYER 3"
SETTING_KEYS = {"xess_driver": (str, type(None)), "xess_shim_system": (bool,)}
UI_KEY = re.compile(r"^ui_[A-Za-z0-9_]{1,60}$")
MAX_SETTING_BYTES = 4096
MAX_UI_KEYS = 64
POWER_TICK_S = 2                     # the power watch loop's period: power.TICK_S (a test keeps them equal)
UNLOAD_EXTRAS_S = 3                  # extras.unload's budget: Decky kills the process 5 s after asking it to stop
REBOOT_KEY = "oxp3_reboot_pending"   # settings.json: {boot_id, value} from the last oxp3-tool status
OXP3_STILL_RUNNING = ("the plugin restarted while oxp3-tool was running; it may still be running: read the status "
                      "when it has ended")
# oxp3tool.py's files in /run/oxp3deck: <cmd>-<date>-<time>-<hex>.out/.err of a run, oxp3-diagnose-...tar.gz
OXP3_OUTPUT = re.compile(r"[a-z][a-z0-9-]*-\d{8}-\d{6}-[0-9a-f]{6}\.(?:out|err|tar\.gz)")
# userexec.run(detach=True)'s output file of an xess-xmx-linux script there: user-<date>-<time>-<hex>.log
SCRIPT_OUTPUT = re.compile(r"user-\d{8}-\d{6}-[0-9a-f]{6}\.log")
NO_OXP3 = {"installed": False, "path": None, "version": None, "json_ok": False, "min_version": "0.4.2",
           "bundled_version": None}   # min_version: oxp3tool.MIN_VERSION_TEXT (a test keeps them equal)


class Unavailable(Exception):
    """A call that cannot run: its message is the whole answer."""


def _mod(name: str):
    mod = globals().get(name)
    if mod is None:
        raise Unavailable(f"the {name} module did not load: {_BROKEN.get(name, 'unknown error')}")
    return mod


def _sendable(value):
    """value as Decky can send it: JSON types only (anything else as its str), and text that encodes as UTF-8. A
    lone surrogate (a file name that is not UTF-8, as os.scandir gives it) becomes "?": Decky's own encode would
    fail, no answer would be written and the frontend's call would never settle."""
    return json.loads(json.dumps(value, default=str, ensure_ascii=False).encode("utf-8", "replace"))


def _answer(name: str, res) -> dict:
    if not isinstance(res, dict):
        return {"ok": False, "error": f"{name}: returned {type(res).__name__}, not a dict"}
    res = _sendable(res)
    res["ok"] = bool(res.get("ok"))
    res.setdefault("error", None)
    return res


def _read_text(path: str, limit: int = 65536) -> str:
    try:
        with open(path, "rb") as f:
            return f.read(limit).decode("utf-8", errors="replace")
    except OSError:
        return ""


def _platform(ctx):
    """"cachyos" or "bazzite" from os-release (ID, then ID_LIKE; CachyOS repositories on an Arch ID count, as in
    oxp3_tool/detect.py), else None."""
    text = _read_text(ctx.sys_path("/etc/os-release")) or _read_text(ctx.sys_path("/usr/lib/os-release"))
    rel = {}
    for line in text.splitlines():
        k, sep, v = line.partition("=")
        if sep and k.strip() and not k.startswith("#"):
            rel[k.strip()] = v.strip().strip("\"'")
    ids = [rel.get("ID", "")] + rel.get("ID_LIKE", "").split()
    for name in ("cachyos", "bazzite"):
        if name in ids:
            return name
    if rel.get("ID") == "arch" and re.search(r"^\[cachyos", _read_text(ctx.sys_path("/etc/pacman.conf")), re.M):
        return "cachyos"
    return None


def _device(ctx) -> dict:
    def dmi(field):
        return _read_text(ctx.sys_path(f"/sys/class/dmi/id/{field}"), 256).strip() or None
    vendor, product = dmi("sys_vendor"), dmi("product_name")
    return {"vendor": vendor, "product": product, "supported": vendor == OXP3_VENDOR and product == OXP3_PRODUCT}


def _title(verb: str, names) -> str:
    names = [str(n) for n in names] if isinstance(names, (list, tuple)) else []
    if not names:
        return verb
    return f"{verb} {', '.join(names[:4])}{' and more' if len(names) > 4 else ''}"


class Plugin:
    def __init__(self):
        self.ctx = None
        self.settings = None
        self.jobs = None
        self._broken = None
        self._boot = None
        self._watch = None
        try:
            self.ctx = context.from_decky()
            self.settings = context.Settings(os.path.join(self.ctx.settings_dir, "settings.json"))
            self.jobs = jobs.Jobs(self.ctx.runtime_dir)
            log.info("OXP3Deck %s for %s (%s)", getattr(decky, "DECKY_PLUGIN_VERSION", "?"), self.ctx.user,
                     self.ctx.home)
        except Exception as e:
            self._broken = f"{type(e).__name__}: {e}"
            log.error("OXP3Deck cannot start:\n%s", traceback.format_exc())
            return
        self._after_restart()

    def _after_restart(self) -> None:
        """What an earlier plugin process left (here, before Decky serves any call, so no new oxp3-tool run can
        start in between). Its oxp3-tool run has its own session and output files, so it outlives the plugin: while
        oxp3-tool's lock is held, an interrupted oxp3-tool job says it may still be running; once nothing holds it,
        the run's leftover output files in /run/oxp3deck go. The same for a detached xess-xmx-linux script's output
        file once that script has ended (xess.script_running): nobody follows it any more."""
        try:
            tool = _mod("oxp3tool")
            if tool.tool_running(self.ctx):
                for job in self.jobs.interrupted:
                    if job.kind.startswith("oxp3-") and job.kind != "oxp3-install":   # install runs no oxp3-tool
                        self.jobs.set_error(job, OXP3_STILL_RUNNING)
            else:
                sysexec.remove_files(self.ctx, OXP3_OUTPUT)
        except Exception:
            log.error("start-up tidy-up failed (carrying on):\n%s", traceback.format_exc())
        try:
            if _mod("xess").script_running(self.ctx) is None:
                sysexec.remove_files(self.ctx, SCRIPT_OUTPUT)
        except Exception:
            log.error("start-up tidy-up of script output failed (carrying on):\n%s", traceback.format_exc())

    # ---- plumbing ------------------------------------------------------------------------------------------------

    def _check(self) -> None:
        if self._broken:
            raise Unavailable(f"the plugin could not start: {self._broken}")

    async def _call(self, name: str, fn, *args) -> dict:
        """fn(*args) in the default executor; whatever happens, a dict with ok and error."""
        try:
            self._check()
            res = await asyncio.get_running_loop().run_in_executor(None, functools.partial(fn, *args))
            return _answer(name, res)
        except Unavailable as e:
            return _answer(name, {"ok": False, "error": f"{name}: {e}"})   # the text can hold a path
        except Exception as e:
            log.error("%s failed:\n%s", name, traceback.format_exc())
            return _answer(name, {"ok": False, "error": f"{name}: {type(e).__name__}: {e}"})

    async def _start(self, name: str, kind: str, title: str, work, precheck=None) -> dict:
        """Start work(job) as a job: {ok, error, job}. precheck() -> why not (or None) runs first, so a bad
        argument is refused before anything starts."""
        def go():
            running = self.jobs.running()
            if running is not None:
                return {"ok": False, "error": f"another task is running: {running.title}", "job": None}
            why = precheck() if precheck is not None else None
            if why:
                return {"ok": False, "error": why, "job": None}
            job, why = self.jobs.start(kind, title, work)
            return {"ok": job is not None, "error": why, "job": job.to_dict() if job else None}

        res = await self._call(name, go)
        res.setdefault("job", None)
        return res

    def _not_during_xess_job(self, what: str) -> None:
        running = self.jobs.running()
        if running is not None and running.kind.startswith("xess"):
            raise Unavailable(f"{running.title} is running; {what} when it has ended")

    def _boot_id(self):
        if self._boot is None:
            self._boot = _read_text(self.ctx.sys_path("/proc/sys/kernel/random/boot_id"), 100).strip()
        return self._boot

    def _note_reboot(self, value: bool) -> None:
        mark = {"boot_id": self._boot_id(), "value": bool(value)}
        if self.settings.get(REBOOT_KEY) != mark:
            self.settings.set(REBOOT_KEY, mark)

    def _reboot_pending(self) -> bool:
        mark = self.settings.get(REBOOT_KEY)
        return isinstance(mark, dict) and mark.get("value") is True and mark.get("boot_id") == self._boot_id()

    # ---- lifecycle -----------------------------------------------------------------------------------------------

    async def _main(self):
        """A pacman update of proton-cachyos puts the stock DLL back: shim the system Protons again when needed.
        Then the power watch task starts (power.tick every POWER_TICK_S); _main itself returns."""
        try:
            self._check()
            await asyncio.get_running_loop().run_in_executor(None, self._reshim)
        except Exception:
            log.error("start-up check failed (carrying on):\n%s", traceback.format_exc())
        if self._broken is None and self._watch is None:
            self._watch = asyncio.get_running_loop().create_task(self._power_watch())

    async def _power_watch(self):
        """AC changes, resume, the boot apply and drift are seen here (DESIGN.md "Events"), then the extras' tick
        (fan safety, fan and scheduler mode, intel_lpmd, charge), in the executor. An error is logged (the same text
        once in a row) and the loop goes on; a module that did not load ends its own part, and the loop ends when
        neither part is left. A part still running after POWER_TICK_S (a D-Bus service that hangs) is not waited
        for: the other part goes on, and the slow one is started again only once it has finished."""
        last = {"power": None, "extras": None}
        parts = {"power": self._power_tick, "extras": self._extras_tick}
        running: dict = {}

        def finished(name, fut) -> None:
            try:
                fut.result()
                last[name] = None
            except Unavailable as e:
                log.error("%s watch stopped: %s", name, e)
                parts.pop(name, None)
            except Exception as e:
                text = f"{type(e).__name__}: {e}"
                if text != last[name]:
                    log.error("%s watch: %s", name, "".join(traceback.format_exception(e)))
                last[name] = text

        while parts:
            await asyncio.sleep(POWER_TICK_S)
            for name, step in list(parts.items()):
                fut = running.get(name)
                if fut is not None:
                    if not fut.done():
                        continue                       # still busy: skip this pass
                    del running[name]
                    finished(name, fut)
                    if name not in parts:
                        continue
                fut = asyncio.get_running_loop().run_in_executor(None, step)
                await asyncio.wait({fut}, timeout=POWER_TICK_S)
                if fut.done():
                    finished(name, fut)
                else:
                    running[name] = fut
                    log.warning("%s watch: a step takes longer than %s s; the other part goes on", name,
                                POWER_TICK_S)

    def _power_tick(self) -> None:
        _mod("power").tick(self.ctx)

    def _power_active(self):
        """power.active(ctx), or None when the power module is not there or fails (the extras then act on no
        profile: only the charge settings and the safety rules)."""
        try:
            return _mod("power").active(self.ctx)
        except Unavailable:
            return None
        except Exception:
            log.error("power.active failed:\n%s", traceback.format_exc())
            return None

    def _after_extras(self, res) -> None:
        """intel_lpmd stopped or started blocking fields: power applies again at its next tick."""
        if isinstance(res, dict) and res.get("lpmd_changed"):
            try:
                _mod("power").refresh(self.ctx)
            except Unavailable:
                pass
            except Exception:
                log.error("power.refresh failed:\n%s", traceback.format_exc())

    def _extras_tick(self) -> None:
        _mod("extras")                      # Unavailable (before power.active) ends the extras part of the loop
        active = self._power_active()
        self._after_extras(_mod("extras").tick(self.ctx, active))

    def _sync_extras(self) -> None:
        """After a power or extras change: the extras follow the active profile at once. Never raises."""
        try:
            _mod("extras")
            active = self._power_active()
            self._after_extras(_mod("extras").sync(self.ctx, active))
        except Unavailable:
            pass
        except Exception:
            log.error("extras sync failed:\n%s", traceback.format_exc())

    def _synced(self, res):
        """res (a power answer), after the extras' sync, which never changes it."""
        self._sync_extras()
        return res

    def _reshim(self) -> None:
        x = _mod("xess")
        if not x.system_protons_need_shim(self.ctx, self.settings):
            return
        job, why = self.jobs.start("xess-reshim", "Shim the system Protons again",
                                   lambda job: x.shim_system_protons(self.ctx, self.settings, job))
        log.info("system Protons lost the shim: %s", f"job {job.id}" if job else why)

    async def _unload(self):
        # Decky kills the process 5 s after asking it to stop, and a running job's own steps end with it. The
        # programs it started do not: oxp3-tool and the xess-xmx-linux scripts (userexec detach) have their own
        # session and write to files in /run/oxp3deck, so they run to their end, EXIT traps included. A short
        # helper (cp, rm, the unpacker) keeps running too but loses its output pipe. The job shows as interrupted
        # at the next start (_after_restart). Power limits stay as they are (DESIGN.md "Power": none outlives a
        # reboot, and a reload must not drop a game's limits); only the watch task stops.
        if self._watch is not None:
            self._watch.cancel()
            self._watch = None
        # The extras are the exception (DESIGN.md "Extras"): the fan back to Auto, the scheduler mode and
        # intel_lpmd put back, the sleep watch stopped.
        if self._broken is None and extras is not None:
            try:
                await asyncio.wait_for(asyncio.get_running_loop().run_in_executor(
                    None, _mod("extras").unload, self.ctx), UNLOAD_EXTRAS_S)
            except asyncio.TimeoutError:
                log.error("extras unload did not end within %d s", UNLOAD_EXTRAS_S)
            except Exception:
                log.error("extras unload failed:\n%s", traceback.format_exc())
        log.info("OXP3Deck unloading")

    async def _uninstall(self):
        # Decky runs this on every update of the plugin too: nothing is reverted or removed here.
        log.info("OXP3Deck removed (or updated): oxp3-tool, its fixes and xess-xmx-linux stay installed")

    # ---- overview ------------------------------------------------------------------------------------------------

    async def get_overview(self):
        return await self._call("get_overview", self._overview)

    def _overview(self) -> dict:
        ctx = self.ctx

        def part(what, fn, default):
            try:
                return fn()
            except Exception as e:
                log.error("overview: %s:\n%s", what, traceback.format_exc())
                return default(e) if callable(default) else default

        job = self.jobs.running()
        return {
            "ok": True, "error": None,
            "plugin_version": str(getattr(decky, "DECKY_PLUGIN_VERSION", "") or ""),
            "user": ctx.user, "home": ctx.home,
            "platform": part("platform", lambda: _platform(ctx), None),
            "device": part("device", lambda: _device(ctx), {"vendor": None, "product": None, "supported": False}),
            "oxp3": part("oxp3-tool", lambda: _mod("oxp3tool").installed(ctx), dict(NO_OXP3)),
            "xess": part("xess", lambda: _mod("xess").summary(ctx, self.settings),
                         lambda e: {"installed": False, "version": None, "status": "unknown",
                                    "line": f"XeSS state unknown: {e}", "live": False, "relogin_needed": False}),
            "job": job.to_dict(tail=20) if job else None,
            "reboot_pending": part("reboot", self._reboot_pending, False),
            "do_not_reboot": part("rebuild marker", lambda: _mod("oxp3tool").rebuild_unfinished(ctx), None),
            "power": part("power", lambda: _mod("power").summary(ctx), None),
        }

    # ---- oxp3-tool -----------------------------------------------------------------------------------------------

    async def oxp3_status(self):
        return await self._call("oxp3_status", self._oxp3_status)

    def _oxp3_status(self) -> dict:
        res = _mod("oxp3tool").status(self.ctx)
        if isinstance(res, dict) and res.get("ok") and isinstance(res.get("status"), dict):
            self._note_reboot(bool(res["status"].get("reboot_pending")))
        return res

    async def oxp3_catalog(self):
        return await self._call("oxp3_catalog", lambda: _mod("oxp3tool").catalog(self.ctx))

    async def oxp3_plan(self, fixes, opts=None):
        return await self._call("oxp3_plan", lambda: _mod("oxp3tool").plan(self.ctx, fixes, opts))

    def _noting_reboot(self, res):
        """An apply or revert whose outcome needs a reboot: "Reboot to finish" shows before the next status."""
        outcome = res.get("outcome") if isinstance(res, dict) else None
        if isinstance(outcome, dict) and outcome.get("reboot_needed"):
            self._note_reboot(True)
        return res

    async def oxp3_apply(self, fixes, opts=None):
        return await self._start("oxp3_apply", "oxp3-apply", _title("Apply", fixes),
                                 lambda job: self._noting_reboot(_mod("oxp3tool").apply(self.ctx, job, fixes, opts)),
                                 lambda: _mod("oxp3tool").apply_args(self.ctx, fixes, opts)[1])

    async def oxp3_revert(self, fixes):
        return await self._start("oxp3_revert", "oxp3-revert", _title("Revert", fixes),
                                 lambda job: self._noting_reboot(_mod("oxp3tool").revert(self.ctx, job, fixes)),
                                 lambda: _mod("oxp3tool").check_fixes(self.ctx, fixes, "revert")[1])

    async def oxp3_kernel(self):
        return await self._call("oxp3_kernel", lambda: _mod("oxp3tool").kernel(self.ctx))

    async def oxp3_kernel_try(self, pkg):
        return await self._start("oxp3_kernel_try", "oxp3-kernel-try", f"Boot {pkg} once",
                                 lambda job: _mod("oxp3tool").kernel_try(self.ctx, job, pkg),
                                 lambda: _mod("oxp3tool").check_kernel_package(pkg))

    async def oxp3_kernel_keep(self):
        return await self._start("oxp3_kernel_keep", "oxp3-kernel-keep", "Keep the running kernel",
                                 lambda job: _mod("oxp3tool").kernel_keep(self.ctx, job))

    async def oxp3_diagnose(self):
        return await self._start("oxp3_diagnose", "oxp3-diagnose", "Diagnose archive",
                                 lambda job: _mod("oxp3tool").diagnose(self.ctx, job))

    async def oxp3_update_check(self):
        return await self._call("oxp3_update_check", lambda: _mod("oxp3tool").update_check(self.ctx, self.settings))

    async def oxp3_install(self, source):
        where = "from the plugin" if source == "bundled" else "from GitHub"
        return await self._start("oxp3_install", "oxp3-install", f"Install oxp3-tool {where}",
                                 lambda job: _mod("oxp3tool").install(self.ctx, self.settings, job, source),
                                 lambda: None if source in ("bundled", "online") else
                                 f"oxp3_install: source must be 'bundled' or 'online', not {source!r}")

    # ---- xess-xmx-linux ------------------------------------------------------------------------------------------

    async def xess_state(self):
        return await self._call("xess_state", lambda: _mod("xess").state(self.ctx, self.settings))

    async def xess_check_update(self):
        return await self._call("xess_check_update", lambda: _mod("xess").check_update(self.ctx, self.settings))

    async def xess_install(self):
        return await self._start("xess_install", "xess-install", "Install xess-xmx-linux",
                                 lambda job: _mod("xess").install(self.ctx, self.settings, job))

    async def xess_uninstall(self):
        return await self._start("xess_uninstall", "xess-uninstall", "Uninstall xess-xmx-linux",
                                 lambda job: _mod("xess").uninstall(self.ctx, self.settings, job))

    async def xess_set_driver(self, prefix):
        def go():
            self._not_during_xess_job("switch the driver")
            return _mod("xess").set_driver(self.ctx, self.settings, prefix)
        return await self._call("xess_set_driver", go)

    async def xess_shim_system_protons(self):
        def go():
            self._not_during_xess_job("shim the system Protons")
            return _mod("xess").shim_system_protons(self.ctx, self.settings)
        return await self._call("xess_shim_system_protons", go)

    async def xess_remove_folder(self, path):
        def go():
            self._not_during_xess_job("remove the folder")
            return _mod("xess").remove_folder(self.ctx, self.settings, path)
        return await self._call("xess_remove_folder", go)

    # ---- per game ------------------------------------------------------------------------------------------------

    async def game_info(self, appid):
        return await self._call("game_info", lambda: _mod("games").game_info(self.ctx, self.settings, str(appid)))

    # ---- OptiScaler per game (DESIGN.md "OptiScaler (0.5)") ---------------------------------------------------------

    def _not_during_opti_job(self) -> None:
        running = self.jobs.running()
        if running is not None and running.kind.startswith("opti"):
            raise Unavailable(f"{running.title} is running; try again when it has ended")

    def _opti_title(self, verb: str, appid) -> str:
        return f"{verb} for {_mod('optiscaler').game_name(self.ctx, str(appid)) or appid}"

    def _opti_precheck(self, appid, choices=None, installing=False):
        """Why the job cannot start, or None: bad choices and the refusals are answered before any job."""
        o = _mod("optiscaler")
        if choices is not None:
            why = o.choices_why(self.ctx, str(appid), choices)
            if why:
                return why
        return o.check(self.ctx, str(appid), installing=installing)["why"]

    async def opti_info(self, appid):
        return await self._call("opti_info", lambda: _mod("optiscaler").info(self.ctx, appid, self.settings))

    async def opti_install(self, appid, choices):
        return await self._start("opti_install", "opti-install", self._opti_title_safe("OptiScaler", appid),
                                 lambda job: _mod("optiscaler").install(self.ctx, self.settings, job, appid, choices),
                                 lambda: self._opti_precheck(appid, choices, installing=True))

    async def opti_set(self, appid, choices):
        def go():
            self._not_during_opti_job()
            return _mod("optiscaler").set_choices(self.ctx, appid, choices, self.settings)
        return await self._call("opti_set", go)

    async def opti_remove(self, appid):
        return await self._start("opti_remove", "opti-remove", self._opti_title_safe("Remove OptiScaler", appid),
                                 lambda job: _mod("optiscaler").remove(self.ctx, self.settings, job, appid),
                                 lambda: self._opti_precheck(appid))

    async def opti_update(self, appid):
        return await self._start("opti_update", "opti-update", self._opti_title_safe("Update OptiScaler", appid),
                                 lambda job: _mod("optiscaler").update(self.ctx, self.settings, job, appid),
                                 lambda: self._opti_precheck(appid))

    async def opti_options(self, opts):
        def go():
            self._not_during_opti_job()
            return _mod("optiscaler").options(self.ctx, opts)
        return await self._call("opti_options", go)

    def _opti_title_safe(self, verb: str, appid) -> str:
        try:
            return self._opti_title(verb, appid)
        except Exception:
            return f"{verb} for {appid}"

    # ---- automatic setup (DESIGN.md "Automatic setup (0.6)") ---------------------------------------------------------

    async def auto_state(self):
        return await self._call("auto_state", lambda: _mod("autosetup").state(self.ctx))

    async def auto_enable(self, on, confirmed=False):
        return await self._call("auto_enable", lambda: _mod("autosetup").enable(self.ctx, on, confirmed))

    async def auto_pending(self, appids):
        def go():
            if not isinstance(appids, list):
                return {"ok": False, "error": "auto_pending: appids must be a list", "appids": []}
            return _mod("autosetup").pending(self.ctx, appids)
        return await self._call("auto_pending", go)

    async def auto_plan(self, appid, facts):
        return await self._call("auto_plan", lambda: _mod("autosetup").plan(self.ctx, self.settings, appid, facts))

    async def auto_record(self, appid, change):
        return await self._call("auto_record", lambda: _mod("autosetup").record(self.ctx, appid, change))

    async def auto_mode(self, appid, mode, why=None):
        return await self._call("auto_mode", lambda: _mod("autosetup").set_mode(self.ctx, appid, mode, why))

    async def auto_undo(self, appid, change_id, reason="user"):
        """launch / proton: marked (the frontend wrote first); opti: the job "opti-remove", marked when it ends."""
        res = await self._call("auto_undo", lambda: _mod("autosetup").undone(self.ctx, appid, change_id, reason))
        res.setdefault("game", None)
        res["job"] = None
        if not res["ok"] or res.get("kind") != "opti":
            return res
        started = await self._start(
            "auto_undo", "opti-remove", self._opti_title_safe("Remove OptiScaler", appid),
            lambda job: _mod("autosetup").opti_undo(self.ctx, self.settings, job, appid, change_id, reason),
            lambda: _mod("autosetup").opti_undo_precheck(self.ctx, appid, change_id))
        return {"ok": started["ok"], "error": started["error"], "game": res["game"], "job": started.get("job"),
                "kind": "opti"}

    async def auto_retry(self, appid, change_id):
        return await self._call("auto_retry", lambda: _mod("autosetup").retry(self.ctx, appid, change_id))

    async def auto_session(self, appid, event):
        return await self._call("auto_session", lambda: _mod("autosetup").session(self.ctx, appid, event))

    async def auto_opti_install(self, appid, accepted=False):
        return await self._start(
            "auto_opti_install", "opti-install", self._opti_title_safe("OptiScaler", appid),
            lambda job: _mod("autosetup").opti_install(self.ctx, self.settings, job, appid, accepted is True),
            lambda: _mod("autosetup").opti_precheck(self.ctx, self.settings, appid, accepted is True))

    # ---- power (not jobs: no job ever blocks these) ----------------------------------------------------------------

    async def power_info(self, refresh=False):
        refresh = refresh is True
        return await self._call("power_info", lambda: _mod("power").info(self.ctx, refresh))

    async def power_state(self):
        return await self._call("power_state", lambda: _mod("power").state(self.ctx))

    async def power_enable(self, on):
        return await self._call("power_enable", lambda: self._synced(_mod("power").enable(self.ctx, on)))

    async def power_options(self, opts):
        return await self._call("power_options", lambda: self._synced(_mod("power").options(self.ctx, opts)))

    async def power_set(self, key, slot, values):
        return await self._call("power_set",
                                lambda: self._synced(_mod("power").set_values(self.ctx, key, slot, values)))

    async def power_profile(self, appid, name, on):
        return await self._call("power_profile",
                                lambda: self._synced(_mod("power").profile(self.ctx, appid, name, on)))

    async def power_game(self, appid):
        return await self._call("power_game", lambda: self._synced(_mod("power").game(self.ctx, appid)))

    async def power_take_control(self):
        return await self._call("power_take_control", lambda: self._synced(_mod("power").take_control(self.ctx)))

    async def power_import_sdtdp(self):
        return await self._call("power_import_sdtdp", lambda: _mod("power").import_sdtdp(self.ctx))

    async def power_fix(self, cid):
        """Fix for me: stop and disable conflict `cid`'s whitelisted services (the frontend asks first)."""
        return await self._call("power_fix", lambda: _mod("power").fix(self.ctx, cid))

    async def power_unfix(self, cid):
        """Undo of power_fix: enable and start again exactly what it turned off."""
        return await self._call("power_unfix", lambda: _mod("power").unfix(self.ctx, cid))

    async def power_live(self):
        """Live readouts (package W, battery, temperature, GPU busy and clocks, throttling, fan): read only; the
        frontend asks every second while a panel shows."""
        return await self._call("power_live", lambda: _mod("readouts").sample(self.ctx))

    # ---- extras (battery, fan, scheduler mode, intel_lpmd; not jobs) -----------------------------------------------

    async def extras_info(self):
        return await self._call("extras_info", lambda: _mod("extras").info(self.ctx))

    def _extras_changed(self, res):
        """After extras_set / extras_take_control: the sync, then the answer's state again (intel_lpmd may have
        changed)."""
        self._sync_extras()
        if isinstance(res, dict) and res.get("ok"):
            fresh = _mod("extras").info(self.ctx)
            if isinstance(fresh, dict) and fresh.get("ok"):
                res["extras"] = fresh.get("extras")
        return res

    async def extras_set(self, opts):
        return await self._call("extras_set", lambda: self._extras_changed(_mod("extras").set_options(self.ctx, opts)))

    async def extras_take_control(self, what):
        return await self._call("extras_take_control",
                                lambda: self._extras_changed(_mod("extras").take_control(self.ctx, what)))

    # ---- jobs and misc -------------------------------------------------------------------------------------------

    async def job_status(self, job_id=None):
        def go():
            if job_id is not None and not isinstance(job_id, str):
                return {"ok": False, "error": f"job_status: bad task id {job_id!r}", "job": None}
            job = self.jobs.get(job_id or None)
            if job is None and job_id:
                return {"ok": False, "error": f"job_status: no task {job_id}", "job": None}
            return {"ok": True, "error": None, "job": job.to_dict() if job else None}
        return await self._call("job_status", go)

    async def job_list(self):
        return await self._call("job_list", lambda: {"ok": True, "error": None,
                                                     "jobs": [j.to_dict(tail=20) for j in self.jobs.recent(10)]})

    async def reboot(self):
        return await self._call("reboot", self._reboot)

    def _reboot(self) -> dict:
        running = self.jobs.running()
        if running is not None:
            return {"ok": False, "error": f"reboot: {running.title} is running; reboot when it has ended"}
        if _mod("oxp3tool").tool_running(self.ctx):   # e.g. an apply that outlived a plugin restart
            return {"ok": False, "error": "reboot: oxp3-tool is still running; reboot when it has ended"}
        # RS-3: an install.sh (uninstall.sh, switch-driver.sh) from before a plugin restart: no job of ours follows it,
        # and a reboot would cut it off half done
        what = _mod("xess").script_running(self.ctx) if xess is not None else None   # not loaded: nothing to ask
        if what:
            return {"ok": False, "error": f"reboot: an xess-xmx-linux script is still running ({what}); reboot when "
                                          "it has ended"}
        finish = _mod("oxp3tool").rebuild_unfinished(self.ctx)
        if finish:
            return {"ok": False, "error": f"reboot: do not reboot: oxp3-tool's boot-entry rebuild did not finish; "
                                          f"run `sudo {finish}` in a terminal first"}
        systemctl = sysexec.which("systemctl") or "/usr/bin/systemctl"
        r = sysexec.run([systemctl, "reboot"], timeout=60, start_new_session=True)
        if r.rc != 0:
            why = (r.err or r.out).strip().splitlines()[-1:] or [f"exit {r.rc}"]
            return {"ok": False, "error": f"reboot: systemctl reboot: {why[0]}"}
        return {"ok": True, "error": None}

    async def get_setting(self, key):
        """The stored value (DESIGN.md: any), or None for an unknown key."""
        try:
            if self._broken or _setting_key_error(key):
                return None
            return _sendable(self.settings.get(key))   # settings.json is the user's file: "\udc93" is valid JSON
        except Exception:
            log.error("get_setting failed:\n%s", traceback.format_exc())
            return None

    async def set_setting(self, key, value):
        def go():
            why = _setting_key_error(key) or _setting_value_error(key, value)
            if why:
                return {"ok": False, "error": f"set_setting: {why}"}
            if key.startswith("ui_") and self.settings.get(key) is None and \
                    sum(1 for k in self.settings.all() if k.startswith("ui_")) >= MAX_UI_KEYS:
                return {"ok": False, "error": f"set_setting: more than {MAX_UI_KEYS} ui_ settings"}
            err = self.settings.set(key, value)
            return {"ok": err is None, "error": err}
        return await self._call("set_setting", go)


def _setting_key_error(key):
    if not isinstance(key, str) or not (key in SETTING_KEYS or UI_KEY.match(key)):
        return f"{key!r} is not a setting the frontend may use"[:120]
    return None


def _setting_value_error(key, value):
    if key in SETTING_KEYS and not isinstance(value, SETTING_KEYS[key]):
        return f"{key} cannot be {type(value).__name__}"
    if key == "xess_driver" and isinstance(value, str) and not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._+-]{0,63}", value):
        return f"xess_driver: {value[:40]!r} is not a driver version"
    try:
        blob = json.dumps(value, allow_nan=False)
    except (TypeError, ValueError):
        return f"{key}: not a JSON value"
    if len(blob) > MAX_SETTING_BYTES:
        return f"{key}: more than {MAX_SETTING_BYTES} bytes"
    return None
